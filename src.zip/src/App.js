import Home from './Home'
import Delivery from './Delivery'

import './App.css';

import {
  Route,
  Link,
  Switch,
  Redirect
} from 'react-router-dom';

function App() {
  return (
    <div className="App">
      <div className='header'>
        <img src='https://cdn.icon-icons.com/icons2/549/PNG/512/1455739798_Kitchen_Bold_Line_Color_Mix-42_icon-icons.com_53390.png' className='logo'></img>
        <hi>Bread</hi>
      <ul className='menu' >
        
    <li className='m1'><Link to="/" >Главная</Link></li>
    <li className='m2'><Link to="/delivery" >Доставка</Link></li>
      </ul>
      </div>
      <Switch>
        <Route exact path="/" component={Home}/>
        <Route path="/delivery" component={Delivery}/>
        <Redirect to="/"/>
      </Switch>
    </div>
  );
}

export default App;
