import React from 'react'

const Two = () => {
  return (
    <div>
        <h1>Two</h1>
        <p>Text Hi</p>
    </div>
  )
}

export default Two